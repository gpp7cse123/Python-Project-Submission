const chartColors = [
  "#7966e8", "#22b594", "#f18a91", "#6c9bf0", "#e9b65b",
  "#ad7de8", "#56c3d3", "#ec8e5f", "#8d9aa9", "#d77bb6"
];

const categoryData = Array.isArray(window.expenseCategories) ? window.expenseCategories : [];

if (categoryData.length && document.getElementById("expenseChart")) {
  const ctx = document.getElementById("expenseChart").getContext("2d");
  const labels = categoryData.map(item => item.category);
  const values = categoryData.map(item => Number(item.total));

  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: labels.map((_, i) => chartColors[i % chartColors.length]),
        borderWidth: 0,
        hoverOffset: 5,
        spacing: 3,
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "70%",
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#282541",
          padding: 12,
          displayColors: true,
          callbacks: {
            label: context => ` ₹${Number(context.raw).toLocaleString("en-IN", {minimumFractionDigits: 2})}`
          }
        }
      }
    }
  });

  const legend = document.getElementById("categoryLegend");
  if (legend) {
    labels.slice(0, 6).forEach((label, i) => {
      const item = document.createElement("div");
      item.className = "legend-item";
      const dot = document.createElement("span");
      dot.className = "legend-dot";
      dot.style.background = chartColors[i % chartColors.length];
      const name = document.createElement("span");
      name.textContent = label;
      const total = document.createElement("span");
      total.className = "legend-total";
      total.textContent = "₹" + values[i].toLocaleString("en-IN", {maximumFractionDigits: 2});
      item.append(dot, name, total);
      legend.appendChild(item);
    });
  }
}

function openEdit(tx) {
  const modal = document.getElementById("editModal");
  document.getElementById("editForm").action = `/update/${tx.id}`;
  document.getElementById("edit-title").value = tx.title || "";
  document.getElementById("edit-amount").value = tx.amount;
  document.getElementById("edit-date").value = tx.tx_date;
  document.getElementById("edit-type").value = tx.type;
  document.getElementById("edit-category").value = tx.category || "";
  document.getElementById("edit-note").value = tx.note || "";
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
}

function closeEdit() {
  const modal = document.getElementById("editModal");
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}

document.getElementById("editModal")?.addEventListener("click", event => {
  if (event.target.id === "editModal") closeEdit();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeEdit();
});
