MONETA — PERSONAL EXPENSE TRACKER
=================================

Requirements:
- Python 3.10 or newer recommended
- pip

Setup:
1. Open a terminal inside the ExpenseTracker folder.
2. Create a virtual environment (recommended):
   python -m venv .venv

3. Activate it on Windows:
   .venv\Scripts\activate

4. Install requirements:
   pip install -r requirements.txt

5. Start the app:
   python main.py

6. Open the local address printed in the terminal, usually:
   http://127.0.0.1:5000

The SQLite database file (expenses.db) is created automatically in this folder.

Features:
- Add income and expense transactions
- View monthly totals and balance
- Category breakdown chart
- Search and filter transactions
- Edit and delete records
- Local SQLite storage

Note:
This is a local educational project, not a production financial service.
Change app.secret_key before deployment. Do not expose Flask debug mode publicly.
The Chart.js chart and Google Fonts load from external CDNs, so those visual resources
need an internet connection. Core transaction storage works locally.
