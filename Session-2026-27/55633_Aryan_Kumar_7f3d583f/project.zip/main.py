from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from database import (
    init_db, add_transaction, get_transactions, get_summary,
    delete_transaction, update_transaction, get_categories
)
from datetime import date

app = Flask(__name__)
app.secret_key = "change-this-secret-key-for-production"

init_db()


@app.route("/")
def dashboard():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()
    tx_type = request.args.get("type", "").strip()

    summary = get_summary(month)
    transactions = get_transactions(
        month=month,
        search=search,
        category=category,
        tx_type=tx_type
    )
    categories = get_categories()

    return render_template(
        "index.html",
        summary=summary,
        transactions=transactions,
        categories=categories,
        selected_month=month,
        search=search,
        selected_category=category,
        selected_type=tx_type,
        today=date.today().isoformat()
    )


@app.route("/add", methods=["POST"])
def add():
    try:
        amount = float(request.form.get("amount", "0"))
        title = request.form.get("title", "").strip()
        tx_type = request.form.get("type", "").strip()
        category = request.form.get("category", "").strip()
        tx_date = request.form.get("date", "").strip()
        note = request.form.get("note", "").strip()

        if not title or not category or not tx_date:
            raise ValueError("Please fill in all required fields.")
        if amount <= 0:
            raise ValueError("Amount must be greater than zero.")
        if tx_type not in ("income", "expense"):
            raise ValueError("Choose income or expense.")

        add_transaction(title, amount, tx_type, category, tx_date, note)
        flash("Transaction added successfully.", "success")
    except (ValueError, TypeError):
        flash("Please enter valid transaction details.", "error")

    return redirect(url_for("dashboard"))


@app.route("/update/<int:transaction_id>", methods=["POST"])
def update(transaction_id):
    try:
        amount = float(request.form.get("amount", "0"))
        title = request.form.get("title", "").strip()
        tx_type = request.form.get("type", "").strip()
        category = request.form.get("category", "").strip()
        tx_date = request.form.get("date", "").strip()
        note = request.form.get("note", "").strip()

        if not title or not category or not tx_date or amount <= 0:
            raise ValueError
        if tx_type not in ("income", "expense"):
            raise ValueError

        update_transaction(
            transaction_id, title, amount, tx_type, category, tx_date, note
        )
        flash("Transaction updated successfully.", "success")
    except (ValueError, TypeError):
        flash("Please enter valid transaction details.", "error")

    return redirect(url_for("dashboard"))


@app.route("/delete/<int:transaction_id>", methods=["POST"])
def delete(transaction_id):
    delete_transaction(transaction_id)
    flash("Transaction deleted.", "success")
    return redirect(url_for("dashboard"))


@app.route("/api/summary")
def summary_api():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    return jsonify(get_summary(month))


if __name__ == "__main__":
    app.run(debug=True)
