import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "expenses.db"


def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    with get_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                amount REAL NOT NULL CHECK (amount > 0),
                type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
                category TEXT NOT NULL,
                tx_date TEXT NOT NULL,
                note TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_transactions_date
            ON transactions(tx_date)
        """)


def add_transaction(title, amount, tx_type, category, tx_date, note=""):
    with get_connection() as connection:
        connection.execute("""
            INSERT INTO transactions
            (title, amount, type, category, tx_date, note)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (title, amount, tx_type, category, tx_date, note))


def get_transactions(month=None, search="", category="", tx_type=""):
    query = """
        SELECT id, title, amount, type, category, tx_date, note
        FROM transactions
        WHERE 1 = 1
    """
    params = []

    if month:
        query += " AND substr(tx_date, 1, 7) = ?"
        params.append(month)
    if search:
        query += " AND (title LIKE ? OR note LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    if category:
        query += " AND category = ?"
        params.append(category)
    if tx_type in ("income", "expense"):
        query += " AND type = ?"
        params.append(tx_type)

    query += " ORDER BY tx_date DESC, id DESC"

    with get_connection() as connection:
        rows = connection.execute(query, params).fetchall()
        return [dict(row) for row in rows]


def get_summary(month):
    with get_connection() as connection:
        row = connection.execute("""
            SELECT
                COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) AS income,
                COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) AS expenses,
                COUNT(*) AS transaction_count
            FROM transactions
            WHERE substr(tx_date, 1, 7) = ?
        """, (month,)).fetchone()

        category_rows = connection.execute("""
            SELECT category, SUM(amount) AS total
            FROM transactions
            WHERE substr(tx_date, 1, 7) = ? AND type = 'expense'
            GROUP BY category
            ORDER BY total DESC
        """, (month,)).fetchall()

    income = round(float(row["income"]), 2)
    expenses = round(float(row["expenses"]), 2)
    return {
        "income": income,
        "expenses": expenses,
        "balance": round(income - expenses, 2),
        "transaction_count": int(row["transaction_count"]),
        "categories": [
            {"category": item["category"], "total": round(float(item["total"]), 2)}
            for item in category_rows
        ]
    }


def update_transaction(transaction_id, title, amount, tx_type, category, tx_date, note=""):
    with get_connection() as connection:
        connection.execute("""
            UPDATE transactions
            SET title = ?, amount = ?, type = ?, category = ?, tx_date = ?, note = ?
            WHERE id = ?
        """, (title, amount, tx_type, category, tx_date, note, transaction_id))


def delete_transaction(transaction_id):
    with get_connection() as connection:
        connection.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))


def get_categories():
    # Default categories are presented in the form; users can also type their own
    # category through the HTML datalist.
    return [
        "Food", "Travel", "Shopping", "Education", "Bills",
        "Health", "Entertainment", "Salary", "Freelance", "Other"
    ]
